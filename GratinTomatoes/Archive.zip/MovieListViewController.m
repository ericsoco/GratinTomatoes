//
//  MovieListViewController.m
//  GratinTomatoes
//
//  Created by Eric Socolofsky on 3/12/14.
//  Copyright (c) 2014 Eric Socolofsky. All rights reserved.
//

#import "MovieListViewController.h"

@interface MovieListViewController ()
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation MovieListViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
	
	self.tableView.dataSource = self;
	self.tableView.delegate = self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UITableView Implementation

- (int)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return 5;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
	
	cell.textLabel.text = [NSString stringWithFormat:@"Row %d", indexPath.row];
	
	return cell;
}

@end
