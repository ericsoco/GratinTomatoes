//
//  MovieListViewController.h
//  GratinTomatoes
//
//  Created by Eric Socolofsky on 3/12/14.
//  Copyright (c) 2014 Eric Socolofsky. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MovieListViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>

@end
